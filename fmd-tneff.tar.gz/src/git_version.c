const char* git_version(void) { const char* GIT_Version = "5526fd8 ("__DATE__" "__TIME__")"; return GIT_Version; }
