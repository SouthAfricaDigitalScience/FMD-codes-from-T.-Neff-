/**

  \file FormfactorSlave.h

  MPI slave for calculation Projected Matrix Elements


  (c) 2008 Thomas Neff

*/


#ifndef _FORMFACTORSLAVE_H
#define _FORMFACTORSLAVE_H

void FormfactorSlave(void);


#endif
